//
//  main.m
//  Test-MoveTableViewCell
//
//  Created by 李玉枫 on 2018/11/28.
//  Copyright © 2018 李玉枫. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
